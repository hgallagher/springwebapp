package com.ticketapplication.springwebapp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import modele.*;
import org.springframework.transaction.annotation.Transactional;
import repositories.*;

import java.time.LocalDate;
import java.util.Optional;

@Service
public class Facade {

	@PersistenceContext
	EntityManager em;
	@Autowired
	UserRepository userRepository;
	@Autowired
	AdminRepository adminRepository;
	@Autowired
	AgentRepository agentRepository;
	@Autowired
	CustomerRepository customerRepository;
	@Autowired
	ManagerRepository  managerRepository;

	@Autowired
	TicketRepository ticketRepository;
	@Autowired
	MetaTicketRepository metaTicketRepository;
	@Autowired
	ResolutionRepository resolutionRepository;

	@Transactional
	public boolean authentification(String user, String password) {
		try {
			Query q = em.createQuery("select u from User u where u.username = :user and u.password = :password");
			q.setParameter("user", user);
			q.setParameter("password", password);
			if (q.getSingleResult() != null) {
				return true;
			}
		} catch (Exception ex) {
			return false;
		}
		return false;
	}

	@Transactional
	public String getTypeUser(String user) {
		Query q = em.createQuery("select u from User u where u.username = :user");
		q.setParameter("user", user);
		if(q.getSingleResult() instanceof modele.Admin)
			return "admin";
		if(q.getSingleResult() instanceof modele.Agent)
			return "agent";
		if(q.getSingleResult() instanceof modele.Customer)
			return "customer";
		if(q.getSingleResult() instanceof modele.Manager)
			return "manager";
		return null;
	}

	@Transactional
	public void addUser(String role, String username, String password) {
		Utilisateur uti;
		switch (typeU) {
			case "Agent":
				uti = new Agent();
				break;
			case "Manager":
				uti = new Manager();
				break;
			case "Customer":
				uti = new Customer();
				break;
			default:
				throw new IllegalStateException("Unexpected value: " + role);
		}
		uti.setNom(username);
		uti.setMdp(password);
		uti.setTypeU(role);
		userRepository.save(user);
	}

	@Transactional
	public void addApp(String name, String manager) {
		Optional<User> q = userRepository.findById(Manager);
		if(q.isPresent()) {
			Manager manager1 = (Manager) q.get();
			Application ap = new Application();
			app.setName(name);
			app.setManager(manager1);
			appRepo.save(app);
		}
		else {
			System.out.println("This Manager is INVALID !");
		}
	}

	@Transactional
	public void deleteUser(String username) {
		Optional<User> resolution = userRepository.findById(username);
		if(resolution.isPresent()) {
			String role = resolution.get().getrole();
			if(role"" == "Agent") {
				Agent agent = (Agent) resolution.get();
				for(Ticket ticket1 : agent.getTickets()) {
					if(ticket1.getTicketType() == "NonResolvedTicket") {
						ticket1.setAgent(null);
					}
				}
				for(MetaTicket metaTicket1 : agent.getMetaTickets()) {
					if(metaTicket1.getType() == "NonResolvedMetaTicket") {
						metaTicket1.setAgent(null);
					}
				}
			}
		}
		userRepository.deleteById(username);
	}

	@Transactional
	public void addTicket(long ticketId,String description, Date date, String customerName, Sring title, String issueType , String applicationName) {
		Optional<User> resolutionCustomer = userRepository.findById(customerName);
		Optional<Application> resolutionApp = applicationRepository.findById(App);
		if(resolutionAppApp.isPresent() && resolutionClient.isPresent()) {
			Client      client      = (Client) resCli.get();
			Application application = (Application) resolutionApp.get();
			MetaTicket  metaTicket  = null;

			NonResolvedTicket ticket = new NonResolvedTicket();

			ticket.setTicketId(ticketId);
			ticket.setTitle(title);
			ticket.setCustomer(customer);
			ticket.setDate(date);
			ticket.setDescription(description);
			ticket.setApplication(application);
			ticket.setIssueType(issueType);
			ticket.setMetaTicket(metaTicket);
			ticketRepository.save(ticket);
		}
		else {
			System.out.println("This customer application is not VALID!");
		}
	}

	@Transactional
	public void lockTicket(int ticketId, boolean doLock, String myAge) { /*in case the ticket has not been merged and has not been resolved*/
		Optional<Ticket> resolutionTicket = ticketRepository.findById(ticketId);
		if(resolutionTicket.isPresent()) {
			NonResolvedTicket nonResolvedTicket = (NonResolvedTicket) resolutionTicket.get();
			if(doLock) {
				Optional<User> resolutionAge = userRepository.findById(myAge);
				if(resolutionAge.isPresent()) {
					Agent agent = (Agent) resolutionAge.get();
					nonResolvedTicket.setAgent(agent);
				}
				else {
					System.out.println("This Agent is not VALID!");
				}
			}
			else {
				nonResolvedTicket.setAgent(null);
			}
		}
		else {
			System.out.println("Tgis ticket in not VALID !");
		}
	}

	@Transactional
	public void lockMetaTicket(int id, boolean doLock, String myAge) {
		Optional<MetaTicket> resolutionMetaTicket = metaTicketRepository.findById(TicketId);
		if(resolutionMetaTicket.isPresent()) {
			NonResolvedMetaTicket nonResolvedMetaTicket = (NonResolvedMetaTicket) resolutionMetaTicket.get();
			if(doLock) {
				Optional<User> resolutionAge = userRepository.findById(myAge);
				if(resolutionAge.isPresent()) {
					Agent agent = (Agent) resolutionAge.get();
					nonResolvedMetaTicket.setAgent(agent);
				}
				else {
					System.out.println("This Agent is not VALID !");
				}
			}
			else {
				nonResolvedMetaTicket.setAgent(null);
			}
		}
		else {
			System.out.println("This ticket in not VALID !");
		}
	}

	@Transactional
	public void postResolution(int ticketId, String comment, int idResolution, String myAge, Date date , boolean isTicket,) {
		if(isTicket) {
			Optional<Ticket> resolution = ticketRepository.findByTicketId(ticketId);
			if(resolution.isPresent()) {
				ResolvedTicket ticket = (ResolvedTicket) resolution.get(); /*already checked if the ticket has not been resolved*/
				ticket.setTypeT("ResolvedTicket");

				Resolution resolution = new Resolution();
				resolution.setId(idResolution);
				resolution.setResolvedTicket(ticket);
				resolution.setDate(date);
				resolution.setComment(comment);

				resRepo.save(resolution);
			}
			else {
				System.out.println("This Ticket is not VALID !");
			}
		}
		else {
			Optional<MetaTicket> resolution = metaTicketRepository.findById(id);
			if(resolution.isPresent()) {
				ResolvedMetaTicket ticket = (ResolvedMetaTicket) resolution.get(); /*already checked if the ticket has not been resolved*/
				ticket.setType("ResolvedMetaTicket");

				Resolution resolution = new Resolution();
				resolution.setId(idResolution);
				resolution.setResolvedMetaTicket(ticket);
				resolution.setDate(date);
				resolution.setComment(comment);

				resolutionRepository.save(resolution);
			}
			else {
				System.out.println("This Meta-Ticket is not VALID !");
			}
		}
	}
}