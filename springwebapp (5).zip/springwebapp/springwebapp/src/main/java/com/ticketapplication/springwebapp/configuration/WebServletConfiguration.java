package com.ticketapplication.springwebapp.configurati

import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.orm.jpa.support.OpenEntityManagerInViewFilter;
import org.h2.server.web.WebServlet;
import servlets.*;

import javax.servlet.*;
import java.util.EnumSet;

public class WebServletConfiguration implements WebApplicationInitializer {

    @Override
    public void onStartup(ServletContext servletContext) throws ServletException {
        AnnotationConfigWebApplicationContext webctx=new AnnotationConfigWebApplicationContext();
        webctx.register(CutomerWebConfig.class);
        webctx.setServletContext(servletContext);

        ServletRegistration.Dynamic servletAuth = servletContext.addServlet("authentification",new servletAuth());
        servletAuth.setLoadOnStartup(1);
        servletAuth.addMapping("/authentification");

        ServletRegistration.Dynamic servletAdmin = servletContext.addServlet("admin",new servletAdmin());
        servletAdmin.setLoadOnStartup(1);
        servletAdmin.addMapping("/admin");

        ContextLoaderListener contextLoaderListener = new ContextLoaderListener(webctx);
        servletContext.addListener(contextLoaderListener);

        FilterRegistration.Dynamic filter = servletContext.addFilter("emInViewFilter", new OpenEntityManagerInViewFilter());
        filter.addMappingForUrlPatterns(EnumSet.allOf(DispatcherType.class), true, "/*");

        ServletRegistration.Dynamic h2servlet = servletContext.addServlet("h2-console", new WebServlet());
        h2servlet.setLoadOnStartup(2);
        h2servlet.addMapping("/console/*");

    }
}
