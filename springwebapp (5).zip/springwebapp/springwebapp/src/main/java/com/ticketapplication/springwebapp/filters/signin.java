package com.ticketapplication.springwebapp.filters;


import javax.persistence.*;

@Entity
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(discriminatorType = DiscriminatorType.STRING, name = "Role")
public class User {
    @Id
    private String username;
    private String password;
    @Column(name="Role", insertable = false, updatable = false)
    private String role;

    public User() {
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String nom) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {

        this.role = role;
    }
}
