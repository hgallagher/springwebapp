package com.ticketapplication.springwebapp.models;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@DicriminatorValue("Agent")

public class Agent extends User{
    @Id
    private Long agentId;

    private String username;
    private String password;

    @OneToMany(cascade = {CascadeType.MERGE, CascadeType.PERSIST},mappedBy = "agent")
    private Set<Ticket> tickets = new HashSet<>();
    @OneToOne(cascade ={CascadeType.MERGE, CascadeType.PERSIST}, mappedBy = "Agent")
    private Set<MetaTicket> metaTickets = new HashSet<>();
    @ManyToOne
    @JoinColumn(name = "manager_id")
    private Manager manager;
    @ManyToMany
    @Column(name= "Applications")
    private Set<Application> application;
    public Agent(String username, String password, Manager manager) {
        this.username = username;
        this.password = password;
        this.manager = manager;
    }

    public Agent(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public Manager getManager() {
        return manager;
    }

    public void setManager(Manager manager) {
        this.manager = manager;
    }
    public Set<Ticket> getTickets() {
        return tickets;
    }

    public void setTickets(Set<Ticket> tickets) {
        this.tickets = tickets;
    }
    public Set<MetaTicket> getMetaTickets() {
        return metaTickets;
    }
    public void setMetaTickets(Set<MetaTicket> metaTickets) {
        this.metaTickets = metaTickets;
    }
    public Long getAgentId() {
        return agentId
    }
    public void setAgentId(Long agentId) {
        this.agentId = agentId;
    }
    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}