package com.ticketapplication.springwebapp.models;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name="TYPE")

public class MetaTicket {
    @Id
    @GeneratorValue(strategy = GenerationType.AUTO)
    private Long id;
    @Column(name="TYPE")
    @ManyToOne
    @JoinColumn(name = "Agent")
    private Agent agent;
    @OneToMany(mappedBy = "metaTicket")
    private Set<Ticket> tickets;

    public MetaTicket() {
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public Agent getAgent() {
        return agent;
    }

    public void setAgent(Agent agent) {
        this.agent = agent;
    }

    public Set<Ticket> getTickets() {
        return tickets;
    }

    public void setTickets(Set<Ticket> tickets) {
        this.tickets = tickets;
    }
}
