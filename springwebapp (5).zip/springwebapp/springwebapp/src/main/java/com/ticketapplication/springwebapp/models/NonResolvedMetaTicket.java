package com.ticketapplication.springwebapp.models;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@DicriminatorValue("NonResolvedMetaTicket")

public class NonResolvedMetaTicket extends MetaTicket{

}
