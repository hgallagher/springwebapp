package com.ticketapplication.springwebapp.models;

import javax.persistence.*;
import java.util.Date;

@Entity
@DiscriminatorValue("NonResolvedTicket")
public class NonResolvedTicket extends Ticket{
}
