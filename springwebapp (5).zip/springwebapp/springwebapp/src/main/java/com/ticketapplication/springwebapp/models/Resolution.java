package com.ticketapplication.springwebapp.models;

import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import java.util.Date;

@Entity
public class Resolution {

    @Id
    @GeneratedValue
    private Long resolutionId;
    @DateTimeFormat(pattern="dd-mm-yyyy")
    private Date date;
    @OneToOne
    private ResolvedTicket resolvedTicket;
    @OneToOne
    private ResolvedMetaTicket ResolvedMetaTicket;
    private String comment;

    public Resolution() {
    }

    public Long getResolutionId() {
        return resolutionId;
    }

    public void setResolutionId(Long resolutionId) {
        this.resolutionId = resolutionId;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public ResolvedTicket getResolvedTicket() {
        return resolvedTicket;
    }
    public void setResolvedTicket(ResolvedTicket resolvedTicket){
        this.resolvedTicket = resolvedTicket;
    }
    public ResolvedMetaTicket getResolvedMetaTicket() {
        return ResolvedMetaTicket;
    }

    public void setResolvedMetaTicket(ResolvedMetaTicket resolvedMetaTicket) {
        ResolvedMetaTicket = resolvedMetaTicket;
    }

}

