package com.ticketapplication.springwebapp.models;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@DicriminatorValue("ResolvedMetaTicket")

public class ResolvedMetaTicket extends MetaTicket{
    @OneToOne(mappedBy= "resolvedMetaTicket")
    private Resolution resolution;

    public Resolution getResolution() {
        return resolution;
    }

    public void setResolution(Resolution resolution) {
        this.resolution = resolution;
    }
}
