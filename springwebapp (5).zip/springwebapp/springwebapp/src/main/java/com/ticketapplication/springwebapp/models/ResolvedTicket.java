package com.ticketapplication.springwebapp.models;

import javax.persistence.*;
import java.util.Date;

@Entity
@DiscriminatorValue("ResolvedTicket")
public class ResolvedTicket extends Ticket{
 @OneToOne(mappedBy = "ResolvedTicket")
    private Resolution resolution;

    public Resolution getResolution() {
        return resolution;
    }

    public void setResolution(Resolution resolution) {
        this.resolution = resolution;
    }
}
