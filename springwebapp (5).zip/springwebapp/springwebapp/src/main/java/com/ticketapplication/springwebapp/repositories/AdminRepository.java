package com.ticketapplication.springwebapp.repositories;

import com.ticketapplication.springwebapp.models.Admin;
import org.springframework.data.repository.CrudRepository;

public interface AdminRepository extends CrudRepository<Admin, Long> {
    Admin findByUsernameAndPassword(String username, String password);
}
