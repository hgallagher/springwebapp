package com.ticketapplication.springwebapp.repositories;

import com.ticketapplication.springwebapp.models.Agent;
import org.springframework.data.repository.CrudRepository;

public interface AgentRepository extends CrudRepository<Agent, Long> {
    Agent findByUsernameAndPassword(String username, String password);
}
