package com.ticketapplication.springwebapp.repositories;

import com.ticketapplication.springwebapp.models.Application;
import org.springframework.data.repository.CrudRepository;

public interface ApplicationRepository extends CrudRepository<Application, Long> {
}
