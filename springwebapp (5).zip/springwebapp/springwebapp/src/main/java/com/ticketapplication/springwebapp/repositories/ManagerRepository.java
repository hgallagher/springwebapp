package com.ticketapplication.springwebapp.repositories;

import com.ticketapplication.springwebapp.models.Manager;
import org.springframework.data.repository.CrudRepository;

public interface ManagerRepository extends CrudRepository<Manager, Long> {
    Manager findByUsernameAndPassword(String username, String password);
}
