package com.ticketapplication.springwebapp.repositories;

import com.ticketapplication.springwebapp.models.Ticket;
import org.springframework.data.repository.CrudRepository;

public interface ResolutionRepository extends CrudRepository<Resolution, Long> {
}
