package com.ticketapplication.springwebapp.repositories;

import com.ticketapplication.springwebapp.models.Admin;
import org.springframework.data.repository.CrudRepository;

public interface UserRepository extends CrudRepository<User, Long> {
    UserRepository findByUsernameAndPassword(String username, String password);
}
